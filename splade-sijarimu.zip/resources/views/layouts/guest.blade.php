<div class="font-sans text-gray-900 antialiased">
    {{ $slot }}
</div>
