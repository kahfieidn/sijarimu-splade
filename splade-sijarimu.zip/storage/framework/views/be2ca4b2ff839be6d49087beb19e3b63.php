<SpladeTeleport <?php echo e($attributes); ?>>
    <?php echo e($slot); ?>

</SpladeTeleport><?php /**PATH C:\laragon\www\splade-sijarimu\vendor\protonemedia\laravel-splade\src/../resources/views/functional/teleport.blade.php ENDPATH**/ ?>