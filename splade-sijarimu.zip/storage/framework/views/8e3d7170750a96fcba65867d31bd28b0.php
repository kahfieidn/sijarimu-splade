<SpladeFlash>
    <template #default="<?php echo $scope; ?>">
        <?php echo e($slot); ?>

    </template>
</SpladeFlash><?php /**PATH C:\laragon\www\splade-sijarimu\vendor\protonemedia\laravel-splade\src/../resources/views/functional/flash.blade.php ENDPATH**/ ?>