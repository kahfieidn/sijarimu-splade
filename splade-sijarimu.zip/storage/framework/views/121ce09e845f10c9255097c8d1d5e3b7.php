<?php if (isset($component)) { $__componentOriginalf2931fc266eff6f4b8e92be72ba5930e = $component; } ?>
<?php $component = ProtoneMedia\Splade\Components\Form\Group::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('splade-group'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(ProtoneMedia\Splade\Components\Form\Group::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php $__currentLoopData = $persyaratan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$persyaratan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="py-2">
        <?php if (isset($component)) { $__componentOriginal4cd41e82379e83253fe439725f650e27 = $component; } ?>
<?php $component = ProtoneMedia\Splade\Components\Form\File::resolve(['accept' => 'application/pdf','maxSize' => '2MB','name' => 'field_'.e($key).'','filepond' => true,'preview' => true,'label' => ''.e($key+= 1).'. '.e($persyaratan->nama_persyaratan).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('splade-file'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(ProtoneMedia\Splade\Components\Form\File::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'block mb-2 text-sm font-medium text-gray-900 dark:text-white']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4cd41e82379e83253fe439725f650e27)): ?>
<?php $component = $__componentOriginal4cd41e82379e83253fe439725f650e27; ?>
<?php unset($__componentOriginal4cd41e82379e83253fe439725f650e27); ?>
<?php endif; ?>
        <p class="text-sm text-gray-500 dark:text-gray-300" id="file_input_help">PDF Only (MAX. 2MB).</p>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf2931fc266eff6f4b8e92be72ba5930e)): ?>
<?php $component = $__componentOriginalf2931fc266eff6f4b8e92be72ba5930e; ?>
<?php unset($__componentOriginalf2931fc266eff6f4b8e92be72ba5930e); ?>
<?php endif; ?><?php /**PATH C:\laragon\www\splade-sijarimu\resources\views/components/berkas-pemohon.blade.php ENDPATH**/ ?>