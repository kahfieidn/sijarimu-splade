<SpladeDefer <?php echo e($attributes
    ->mergeVueBinding(':manual', $manual)
    ->mergeVueBinding(':poll', $poll)
    ->mergeVueBinding(':watch-debounce', $watchDebounce)
    ->mergeVueBinding(':watch-value', $watchValue)
    ->mergeVueBinding(':url', $url)); ?>

    <?php if($data): ?> :default="<?php echo \Illuminate\Support\Js::from($data)->toHtml() ?>" <?php else: ?> :default="<?php echo $json; ?>" <?php endif; ?>
    <?php if($headers): ?> :headers="<?php echo \Illuminate\Support\Js::from($headers)->toHtml() ?>" <?php else: ?> :headers="<?php echo $jsonHeaders; ?>" <?php endif; ?>
    <?php if($requestData): ?> :request="<?php echo \Illuminate\Support\Js::from($requestData)->toHtml() ?>" <?php else: ?> :request="<?php echo $requestJson; ?>" <?php endif; ?>>
    <template #default="<?php echo $scope; ?>">
        <?php echo e($slot); ?>

    </template>
</SpladeDefer><?php /**PATH C:\laragon\www\splade-sijarimu\vendor\protonemedia\laravel-splade\src/../resources/views/functional/defer.blade.php ENDPATH**/ ?>