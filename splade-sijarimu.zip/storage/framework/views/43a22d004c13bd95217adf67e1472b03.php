<div class="font-sans text-gray-900 antialiased">
    <?php echo e($slot); ?>

</div>
<?php /**PATH C:\laragon\www\splade-sijarimu\resources\views/layouts/guest.blade.php ENDPATH**/ ?>