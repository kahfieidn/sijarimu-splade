## Sijarimu v1.4

Sistem perizinan online DPMPTSP ini diperuntukkan bagi pemohon yang akan mengajukan permohonan Perizinan Non OSS secara online.